function res = isoctave;
    res = ~ismatlab;
