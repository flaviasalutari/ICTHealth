function s = msize(a);

    asdfdsa;
